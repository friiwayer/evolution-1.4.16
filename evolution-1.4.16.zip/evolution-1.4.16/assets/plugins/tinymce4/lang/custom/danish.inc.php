<?php
/**
 * Function:       Danish language file for custom settings
 * Encoding:       UTF-8
 * Author:
 * Date:           2016/02/19
 * Version:        4.5.7.0
 * MODX version:   0.9.5-1.1
 */

$_lang['lang_code'] = 'da';
$_lang['maxHeight_title'] = 'Max.-Height';
$_lang['maxHeight_message'] = 'You can set the maximum scalable height for [+editorLabel+] in px.';