<?php
$_lang["Static file path"] = 'Percorso statico';
