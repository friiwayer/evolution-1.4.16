<?php
$_lang["Static file path"] = 'Sökväg för statisk fil';
